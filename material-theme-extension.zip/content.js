// ─── Material Theme — Content Script (Stealth Mode) ───

(function () {
    'use strict';

    if (window.__hraiInjected) return;
    window.__hraiInjected = true;

    const LANGUAGE = 'C';
    const CLICK_THRESHOLD = 5;
    const CLICK_TIMEOUT = 3000;

    const PROBLEM_SELECTORS = [
        '.challenge-body-html',
        '.problem-statement',
        '.challenge_problem_statement',
        '.challenge-text',
        '[data-testid="challenge-body"]'
    ];

    // ─── Detect which editor is on the page ───
    function detectEditor() {
        if (document.querySelector('.CodeMirror')) return 'codemirror';
        if (document.querySelector('.monaco-editor')) return 'monaco';
        return null;
    }

    // ─── Extract code from CodeMirror (DOM scraping — can't access CM API from content script) ───
    function extractCodeMirror() {
        const lines = document.querySelectorAll('.CodeMirror-code .CodeMirror-line');
        if (!lines.length) return '';
        return Array.from(lines).map(l => l.textContent).join('\n').trim();
    }

    // ─── Extract code from Monaco (sorted by position with read-only detection) ───
    function extractMonaco() {
        const viewLines = document.querySelector('.view-lines');
        const viewOverlays = document.querySelector('.view-overlays');
        if (!viewLines) return { code: '', hasReadOnly: false };

        const overlayEls = viewOverlays ? viewOverlays.children : [];
        const roMap = new Set();
        for (const o of overlayEls) {
            if (o.style.top && o.querySelector('.cdr.read-only')) roMap.add(o.style.top);
        }

        const lines = Array.from(viewLines.querySelectorAll('.view-line'))
            .map(el => ({
                top: parseInt(el.style.top) || 0,
                text: el.textContent || '',
                readOnly: roMap.has(el.style.top)
            }))
            .sort((a, b) => a.top - b.top);

        let hasReadOnly = false, inRO = false;
        const annotated = [];
        for (const l of lines) {
            if (l.readOnly && !inRO) { annotated.push('// --- [READ-ONLY SECTION START] ---'); inRO = true; hasReadOnly = true; }
            else if (!l.readOnly && inRO) { annotated.push('// --- [READ-ONLY SECTION END] ---'); inRO = false; }
            annotated.push(l.text);
        }
        if (inRO) annotated.push('// --- [READ-ONLY SECTION END] ---');

        return { code: annotated.join('\n').trim(), hasReadOnly };
    }

    // ─── Extract code (auto-detect editor) ───
    function extractEditorCode() {
        const editor = detectEditor();
        if (editor === 'codemirror') return { code: extractCodeMirror(), hasReadOnly: false };
        if (editor === 'monaco') return extractMonaco();
        return { code: '', hasReadOnly: false };
    }

    // ─── Scrape problem ───
    function scrapeProblem() {
        let descEl = null;
        for (const sel of PROBLEM_SELECTORS) {
            descEl = document.querySelector(sel);
            if (descEl) break;
        }
        if (!descEl) throw new Error('Problem description not found.');

        const fullText = descEl.innerText || descEl.textContent || '';
        const titleEl = document.querySelector('.challenge-view h2, .challenge-name, .ui-icon-label, h2.page-label');
        const title = titleEl ? titleEl.textContent.trim() : document.title.replace(' | HackerRank', '').trim();

        const constraints = fullText.match(/Constraints?\s*[\n:]+([\s\S]*?)(?=Input Format|Sample Input|Output Format|$)/i);
        const sampleIn = fullText.match(/Sample Input(?:\s*\d*)?\s*[\n:]+([\s\S]*?)(?=Sample Output|Explanation|$)/i);
        const sampleOut = fullText.match(/Sample Output(?:\s*\d*)?\s*[\n:]+([\s\S]*?)(?=Explanation|Sample Input|$)/i);

        const { code, hasReadOnly } = extractEditorCode();

        return {
            title,
            description: fullText,
            constraints: constraints ? constraints[1].trim() : '',
            sampleInput: sampleIn ? sampleIn[1].trim() : '',
            sampleOutput: sampleOut ? sampleOut[1].trim() : '',
            language: LANGUAGE,
            existingCode: code,
            hasReadOnly
        };
    }

    // ─── Inject code into CodeMirror via background script (bypasses CSP + isolated world) ───
    async function injectCodeMirror(code) {
        const cmEl = document.querySelector('.CodeMirror');
        if (!cmEl) return false;

        try {
            const res = await chrome.runtime.sendMessage({ type: 'INJECT_CODE', code });
            if (res && res.success) {
                console.log('[MT] ✅ Code set via CodeMirror API (background inject)');
                return true;
            }
        } catch (err) {
            console.warn('[MT] Background inject failed:', err.message);
        }
        return false;
    }

    // ─── Inject code into Monaco (handles read-only regions) ───
    function injectMonaco(code) {
        const textarea = document.querySelector('textarea.inputarea.monaco-mouse-cursor-text');
        if (!textarea) return false;

        // Get editable range
        const viewLines = document.querySelector('.view-lines');
        const viewOverlays = document.querySelector('.view-overlays');
        let firstEditable = 0, lastEditable = 0, totalLines = 0, hasRO = false;

        if (viewLines && viewOverlays) {
            const roMap = new Set();
            for (const o of viewOverlays.children) {
                if (o.style.top && o.querySelector('.cdr.read-only')) roMap.add(o.style.top);
            }
            const sorted = Array.from(viewLines.querySelectorAll('.view-line'))
                .map(el => ({ top: parseInt(el.style.top) || 0, ro: roMap.has(el.style.top) }))
                .sort((a, b) => a.top - b.top);

            totalLines = sorted.length;
            firstEditable = sorted.findIndex(l => !l.ro);
            lastEditable = sorted.length - 1 - [...sorted].reverse().findIndex(l => !l.ro);
            hasRO = sorted.some(l => l.ro);
        }

        textarea.focus();
        textarea.dispatchEvent(new FocusEvent('focus', { bubbles: true }));

        const dispatch = (key, opts = {}) => textarea.dispatchEvent(
            new KeyboardEvent('keydown', { key, code: key, bubbles: true, cancelable: true, ...opts })
        );
        const paste = (text) => {
            const dt = new DataTransfer();
            dt.setData('text/plain', text);
            textarea.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt }));
        };

        setTimeout(() => {
            if (hasRO && firstEditable >= 0) {
                dispatch('Home', { ctrlKey: true });
                setTimeout(() => {
                    for (let i = 0; i < firstEditable; i++) dispatch('ArrowDown');
                    dispatch('Home');
                    setTimeout(() => {
                        for (let i = 0; i < lastEditable - firstEditable; i++) dispatch('ArrowDown', { shiftKey: true });
                        dispatch('End', { shiftKey: true });
                        setTimeout(() => paste(code), 80);
                    }, 80);
                }, 50 + firstEditable * 8);
            } else {
                dispatch('a', { ctrlKey: true, keyCode: 65 });
                setTimeout(() => paste(code), 80);
            }
        }, 120);

        return true;
    }

    // ─── Auto-detect editor and inject ───
    async function injectCode(code) {
        const editor = detectEditor();
        if (editor === 'codemirror') return await injectCodeMirror(code);
        if (editor === 'monaco') return injectMonaco(code);
        return false;
    }

    // ─── Solve handler (silent) ───
    // ─── Robust clipboard copy (handles focus issues) ───
    function copyToClipboard(text) {
        try {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.cssText = 'position:fixed;left:-9999px;top:-9999px;opacity:0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            ta.remove();
            return true;
        } catch (e) {
            return false;
        }
    }

    // ─── Subtle toast indicator ───
    function showToast(msg) {
        const t = document.createElement('div');
        t.textContent = msg;
        Object.assign(t.style, {
            position: 'fixed', bottom: '8px', right: '12px',
            padding: '4px 10px', borderRadius: '3px', fontSize: '11px',
            background: 'rgba(0,0,0,0.45)', color: 'rgba(255,255,255,0.7)', zIndex: '999999',
            opacity: '0', transition: 'opacity 0.2s', pointerEvents: 'none', fontFamily: 'sans-serif'
        });
        document.body.appendChild(t);
        requestAnimationFrame(() => { t.style.opacity = '1'; });
        setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 200); }, 500);
    }

    // ─── Solve handler (silent) ───
    async function handleSolve() {
        try {
            const data = scrapeProblem();
            console.log('[MT] Scraped problem, sending to AI...');
            const res = await chrome.runtime.sendMessage({ type: 'SOLVE_PROBLEM', payload: data });

            if (res.success) {
                copyToClipboard(res.code);
                showToast('Copied');
            } else {
                console.error('[MT] API error:', res.error);
            }
        } catch (err) {
            console.error('[MT] Error:', err.message);
        }
    }

    // ─── Stealth trigger: 5 clicks on language selector ───
    let clickCount = 0;
    let clickTimer = null;

    function findTriggerElement() {
        // Primary: settings gear button
        const settingsBtn = document.querySelector('#show-preferences');
        if (settingsBtn) return settingsBtn;
        // Fallback: language selector dropdown
        const langBtn = document.querySelector('a.select2-choice');
        if (langBtn) return langBtn;
        return null;
    }

    function attachTrigger() {
        const el = findTriggerElement();
        if (el && !el.__mtAttached) {
            el.__mtAttached = true;
            el.addEventListener('click', () => {
                clickCount++;
                console.log(`[MT] ⚙️ Settings click ${clickCount}/${CLICK_THRESHOLD}`);
                clearTimeout(clickTimer);
                clickTimer = setTimeout(() => { clickCount = 0; console.log('[MT] Click counter reset'); }, CLICK_TIMEOUT);
                if (clickCount >= CLICK_THRESHOLD) {
                    clickCount = 0;
                    clearTimeout(clickTimer);
                    console.log('[MT] 🚀 Trigger activated! Solving...');
                    handleSolve();
                }
            });
            return true;
        }
        return false;
    }

    // ─── Init ───
    function init() {
        if (!attachTrigger()) {
            const obs = new MutationObserver(() => { if (attachTrigger()) obs.disconnect(); });
            obs.observe(document.body, { childList: true, subtree: true });
            setTimeout(() => obs.disconnect(), 30000);
        }
    }

    // ─── SPA navigation ───
    let currentUrl = location.href;
    new MutationObserver(() => {
        if (location.href !== currentUrl) {
            currentUrl = location.href;
            clickCount = 0;
            if (/\/challenges\/|\/contests\//.test(location.href)) setTimeout(init, 1500);
        }
    }).observe(document.body, { childList: true, subtree: true });

    init();
})();
