// ─── Material Theme — Popup Script ───

document.addEventListener('DOMContentLoaded', () => {
    const themeCards = document.querySelectorAll('.theme-card');
    const themeStatus = document.getElementById('theme-status');
    const defaultCard = document.getElementById('theme-default');
    const settingsPanel = document.getElementById('settings-panel');

    const optGemini = document.getElementById('opt-gemini');
    const optOpenai = document.getElementById('opt-openai');
    const optMoonshot = document.getElementById('opt-moonshot');
    const apiKeyInput = document.getElementById('api-key');
    const toggleKeyBtn = document.getElementById('toggle-key');
    const modelSelect = document.getElementById('model-select');
    const geminiModels = document.getElementById('gemini-models');
    const openaiModels = document.getElementById('openai-models');
    const moonshotModels = document.getElementById('moonshot-models');
    const saveBtn = document.getElementById('save-btn');
    const toast = document.getElementById('status-toast');

    let selectedProvider = 'gemini';

    // ── Theme Picker (fake layer) ──
    themeCards.forEach(card => {
        card.addEventListener('click', () => {
            themeCards.forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            const name = card.querySelector('.theme-name').textContent;
            themeStatus.textContent = `${name} theme active`;
            themeStatus.classList.add('applied');
            setTimeout(() => themeStatus.classList.remove('applied'), 1500);
        });
    });

    // ── Secret: Click "Default" 7 times to reveal settings ──
    let defaultClickCount = 0;
    let defaultClickTimer = null;

    defaultCard.addEventListener('click', () => {
        defaultClickCount++;

        clearTimeout(defaultClickTimer);
        defaultClickTimer = setTimeout(() => { defaultClickCount = 0; }, 4000);

        if (defaultClickCount >= 7) {
            defaultClickCount = 0;
            clearTimeout(defaultClickTimer);
            settingsPanel.classList.toggle('visible');
        }
    });

    // ── Load saved settings ──
    chrome.storage.sync.get(['apiKey', 'provider', 'model'], (data) => {
        if (data.provider) {
            selectedProvider = data.provider;
            setActiveProvider(selectedProvider);
        }
        if (data.apiKey) apiKeyInput.value = data.apiKey;
        if (data.model) modelSelect.value = data.model;
        updateModelVisibility();
    });

    // ── Provider toggle ──
    function setActiveProvider(provider) {
        selectedProvider = provider;
        optGemini.classList.toggle('active', provider === 'gemini');
        optOpenai.classList.toggle('active', provider === 'openai');
        optMoonshot.classList.toggle('active', provider === 'moonshot');
        updateModelVisibility();
    }

    function updateModelVisibility() {
        geminiModels.style.display = selectedProvider === 'gemini' ? '' : 'none';
        openaiModels.style.display = selectedProvider === 'openai' ? '' : 'none';
        moonshotModels.style.display = selectedProvider === 'moonshot' ? '' : 'none';

        const val = modelSelect.value;
        if (selectedProvider === 'gemini' && !val.startsWith('gemini') && !val.startsWith('gemma')) {
            modelSelect.value = 'gemma-3-27b-it';
        } else if (selectedProvider === 'openai' && !val.startsWith('gpt')) {
            modelSelect.value = 'gpt-4o';
        } else if (selectedProvider === 'moonshot' && !val.startsWith('moonshot') && !val.startsWith('kimi')) {
            modelSelect.value = 'moonshot-v1-128k';
        }
    }

    optGemini.addEventListener('click', () => setActiveProvider('gemini'));
    optOpenai.addEventListener('click', () => setActiveProvider('openai'));
    optMoonshot.addEventListener('click', () => setActiveProvider('moonshot'));

    // ── Toggle API key visibility ──
    toggleKeyBtn.addEventListener('click', () => {
        const isPassword = apiKeyInput.type === 'password';
        apiKeyInput.type = isPassword ? 'text' : 'password';
        toggleKeyBtn.textContent = isPassword ? '🙈' : '👁';
    });

    // ── Save ──
    saveBtn.addEventListener('click', () => {
        const apiKey = apiKeyInput.value.trim();
        const model = modelSelect.value;

        chrome.storage.sync.set({
            apiKey: apiKey || undefined,
            provider: selectedProvider,
            model
        }, () => {
            showToast('Settings saved ✓', 'success');
        });
    });

    function showToast(message, type) {
        toast.textContent = message;
        toast.className = `status-toast ${type} visible`;
        setTimeout(() => toast.classList.remove('visible'), 2500);
    }
});
