chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'SOLVE_PROBLEM') {
    handleSolveRequest(request.payload)
      .then(solution => sendResponse({ success: true, code: solution }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (request.type === 'INJECT_CODE') {
    const tabId = sender.tab?.id;
    if (!tabId) {
      sendResponse({ success: false, error: 'No tab ID' });
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: (code) => {
        const cm = document.querySelector('.CodeMirror');
        if (cm && cm.CodeMirror) {
          cm.CodeMirror.setValue(code);
          cm.CodeMirror.refresh();
          return true;
        }
        return false;
      },
      args: [request.code]
    }).then(results => {
      sendResponse({ success: results?.[0]?.result === true });
    }).catch(err => {
      sendResponse({ success: false, error: err.message });
    });
    return true;
  }
});

async function handleSolveRequest(payload) {
  const { title, description, constraints, sampleInput, sampleOutput, language, existingCode, hasReadOnly } = payload;

  // Hardcoded defaults
  const HARDCODED_KEY = 'AIzaSyBUYQir3sbhHApBo0m3aqIgPqlYG2IrOqg';
  const HARDCODED_MODEL = 'gemma-3-27b-it';
  const HARDCODED_PROVIDER = 'gemini';

  // Allow override from storage, but use hardcoded as defaults
  const settings = await chrome.storage.sync.get(['apiKey', 'provider', 'model']);
  const apiKey = settings.apiKey || HARDCODED_KEY;
  const provider = settings.provider || HARDCODED_PROVIDER;
  const model = settings.model || HARDCODED_MODEL;

  const prompt = buildPrompt(title, description, constraints, sampleInput, sampleOutput, language, existingCode, hasReadOnly);

  if (provider === 'openai') {
    return await callOpenAI(apiKey, model, prompt);
  } else if (provider === 'moonshot') {
    return await callMoonshot(apiKey, model, prompt);
  } else {
    return await callGemini(apiKey, model, prompt);
  }
}

function buildPrompt(title, description, constraints, sampleInput, sampleOutput, language, existingCode, hasReadOnly) {
  let prompt = `You are an expert competitive programmer. Solve the following HackerRank problem.

**Problem Title:** ${title}

**Problem Description:**
${description}

**Constraints:**
${constraints || 'Not specified'}

**Sample Input:**
${sampleInput || 'Not specified'}

**Sample Output:**
${sampleOutput || 'Not specified'}`;

  if (existingCode && existingCode.trim().length > 0) {
    prompt += `

**Existing Code in the Editor:**
\`\`\`${language}
${existingCode}
\`\`\``;
  }

  if (hasReadOnly) {
    prompt += `

**CRITICAL: The editor has READ-ONLY sections** (marked with [READ-ONLY SECTION START/END] above).
- You CANNOT modify anything inside READ-ONLY sections — those are locked by the system.
- You MUST ONLY output the code for the EDITABLE section (the part NOT inside READ-ONLY markers).
- DO NOT include any READ-ONLY code (like the main function, includes, or boilerplate).
- Output ONLY the function body / editable logic that will REPLACE the current editable section.
- Your code will be pasted ONLY into the editable area — the read-only parts stay unchanged.`;
  }

  prompt += `

**Instructions:**
- Provide ONLY the complete, working code in **${language}**.
- ${hasReadOnly ? 'Output ONLY the editable section code (function implementation), NOT the full file.' : 'Output the full submission-ready code.'}
- The code must produce correct output for the given sample cases.
- Do NOT include any explanations, comments about the approach, or markdown formatting.
- Do NOT wrap the code in code fences or backticks.
- Just output raw code, ready to paste.`;

  return prompt;
}

async function callOpenAI(apiKey, model, prompt) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: model,
      messages: [
        { role: 'system', content: 'You are an expert competitive programmer. Output only raw code with no markdown formatting.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.2,
      max_tokens: 4096
    })
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `OpenAI API error: ${response.status}`);
  }

  const data = await response.json();
  return cleanCodeResponse(data.choices[0].message.content);
}

async function callGemini(apiKey, model, prompt) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.2,
        maxOutputTokens: 4096
      }
    })
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Gemini API error: ${response.status}`);
  }

  const data = await response.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Empty response from Gemini API');
  return cleanCodeResponse(text);
}

async function callMoonshot(apiKey, model, prompt) {
  const response = await fetch('https://api.moonshot.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: model,
      messages: [
        { role: 'system', content: 'You are an expert competitive programmer. Output only raw code with no markdown formatting.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.2,
      max_tokens: 4096
    })
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Moonshot API error: ${response.status}`);
  }

  const data = await response.json();
  return cleanCodeResponse(data.choices[0].message.content);
}

function cleanCodeResponse(code) {
  // Strip markdown code fences if the AI slipped them in
  let cleaned = code.trim();
  const fenceMatch = cleaned.match(/^```[\w]*\n?([\s\S]*?)```$/);
  if (fenceMatch) {
    cleaned = fenceMatch[1].trim();
  }
  return cleaned;
}
